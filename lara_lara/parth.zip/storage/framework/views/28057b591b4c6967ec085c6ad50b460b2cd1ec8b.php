<?php if(session('Message')): ?>

<?php echo e(session('Message')); ?>

<?php endif; ?>
<table border="2">
<tr>
<th>name</th>
<th>email</th>
<th colspan= "2"> Action </th>
</tr>

<?php $__currentLoopData = $akash; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td> <?php echo e($val->name); ?> </td>
<td> <?php echo e($val->email); ?> </td>
<td> 
<form method="POST" action="<?php echo e(url('delete',$val->id)); ?>">
<?php echo e(method_field('DELETE')); ?>

<?php echo e(csrf_field()); ?>

    <input type="submit" name="delete" value="DELETE">
</form>
 </td>
 <td> <a href = "update/<?php echo e(Crypt::encryptString($val->id)); ?>"> UPDATE </a>    </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</table>