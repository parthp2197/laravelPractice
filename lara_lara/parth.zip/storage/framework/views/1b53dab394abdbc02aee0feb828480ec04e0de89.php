  

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demos.jeweltheme.com/hi5dash/dark/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Mar 2019 05:30:18 GMT -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Hi5Dash - HTML5 Admin Template By Jewel Theme</title>
  <meta name="description" content="Hi5Dash - HTML5 Admin Template By Jewel Theme">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

 <?php echo $__env->make('Admin.Common.link', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</head>


<body class="index-01">


<?php echo $__env->make('Admin.Common.Header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <div class="content-wrapper container-fluid">
  <?php echo $__env->make('Admin.Common.Navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->yieldContent('main_content'); ?>

    <?php echo $__env->make('Admin.Common.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
</div>



  <?php echo $__env->make('Admin.Common.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
    $(function() {
      "use strict";

      $('#calendar').fullCalendar();

    });
  </script>

</body>

<!-- Mirrored from demos.jeweltheme.com/hi5dash/dark/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Mar 2019 05:30:54 GMT -->
</html>