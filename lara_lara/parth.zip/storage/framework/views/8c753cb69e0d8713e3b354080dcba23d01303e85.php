<table border="2">
<tr>
<th>Name</th>
<th>Last name</th>
<th>Email</th>
<th>Password</th>
<th>Gender</th>
<th>DOB</th>
<th>Image</th>
<th>Bobbies</th>
<th colspan="2">Action</th>
</tr>

<?php $__currentLoopData = $disp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td><?php echo e($val->name); ?></td>
<td><?php echo e($val->lname); ?></td>
<td><?php echo e($val->email); ?></td>
<td><?php echo e($val->password); ?></td>
<td><?php echo e($val->gender); ?></td>
<td><?php echo e($val->DOB); ?></td>
<td><?php echo e($val->image); ?></td>
<td><?php echo e($val->Hobbies); ?></td>

<td>

<form method="POST" action="<?php echo e(url('tdelete',$val->id)); ?>">
<?php echo e(method_field('DELETE')); ?>

<?php echo e(csrf_field()); ?>

<input type="submit" name="pdelete" value="Delete">
</form>

</td>
<td><a href="tupdate/<?php echo e(Crypt::encryptString($val->id)); ?>">Update</a></td>
</tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
