
<?php if(session('message')): ?>
<div class="alert alert-success" > 
<?php echo e(session('message')); ?>

</div>
<?php endif; ?>

<table border="2">
<tr>
<th>Name</th>
<th>Last name</th>
<th>Email</th>
<th>Password</th>
<th>Gender</th>
<th>DOB</th>
<th>Image</th>
<th>Hobbies</th>
<th colspan="2">Action</th>
</tr>


<?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($val->orm_fname); ?></td>
<td><?php echo e($val->orm_lname); ?></td>
<td><?php echo e($val->orm_email); ?></td>
<td><?php echo e($val->orm_password); ?></td>
<td><?php echo e($val->orm_gender); ?></td>
<td><?php echo e($val->orm_dob); ?></td>
<td><?php echo e($val->orm_image); ?></td>
<td><?php echo e($val->orm_hobbies); ?></td>

<td>
<form method="POST" action="<?php echo e(url('orm_delete',$val->orm_id)); ?>">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>

<input type="submit" name="orm_delete" value="Delete">
</form>
</td>

</td>
<td><a href="orm_update/<?php echo e(Crypt::encryptString($val->orm_id)); ?>">Update</a></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>