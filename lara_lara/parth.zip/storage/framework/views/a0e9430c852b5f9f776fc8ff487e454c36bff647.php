<table border="1">
<tr>
<th>Name</th>
<th>Email</th>
<th colspan="2">Action</th>
</tr>

<?php $__currentLoopData = $parth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td><?php echo e($val->name); ?></td>
<td><?php echo e($val->email); ?></td>

<td>
<form method="POST" action="<?php echo e(url('pdelete',$val->id)); ?>">
<?php echo e(method_field('DELETE')); ?>

<?php echo e(csrf_field()); ?>

<input type="submit" name="pdelete" value="Delete">
</form>

</td>
<td><a href="pupdate/<?php echo e(Crypt::encryptString($val->id)); ?>">Update</a></td>
</tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
