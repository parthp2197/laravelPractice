<?php echo e("bahot hard...bahot hard"); ?>

<a href="<?php echo e(url('custom_logout')); ?>">LOGOUT</a>