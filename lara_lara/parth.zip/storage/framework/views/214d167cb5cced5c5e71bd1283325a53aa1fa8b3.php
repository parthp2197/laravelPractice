<h2><?php echo e('EDit'); ?> </h2>
<?php $__currentLoopData = $edit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(url('edit',$val->id)); ?>">
<?php echo e(csrf_field()); ?>

<label> name </label>
<input type="text" name="name" value="<?php echo e($val->name); ?>"><br>
<label> lname</label>
<input type="text" name="lname" value="<?php echo e($val->lname); ?>"><br>
<label> email</label>
<input type="email" name="email" value="<?php echo e($val->email); ?>"  ><br>

<label>Gender </label>
<input type="radio" name="gender"  <?php if($val->gender  == 'male'): ?>  checked  <?php endif; ?>  value="male"> Male
<input type="radio" name="gender"  <?php if($val->gender == 'female'): ?>  checked  <?php endif; ?> value="female"> Female <br> 
<label> Dob </label>
<input type="date" name="dob" value="<?php echo e($val->dob); ?>">
<input type="submit" name="submit" value="update">
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>