<form mthod="POST" action="<?php echo e(url('authenticate')); ?>">
<?php echo e(csrf_field()); ?>


    <table>
        <tr>
            <td>email</td>
            <td><input type="email" name="email" id="email"><?php echo e($errors->first('email')); ?></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type="password" name="password" id="password"><?php echo e($errors->first('password')); ?></td>
        </tr>
        <tr>
            <td>
            <input type="submit" name="submit" value="LOGHIN">
            </td>
        </tr>
        <tr>
            <td>
            <a href="<?php echo e(url('redirect')); ?>" class="btn btn-primary">Login With Google</a>
            </td>
        </tr>
    </table>

</form>