<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orm extends Model
{
    //
    protected $table = "orm";
    protected $id = "orm_id";
}
