{{ "bahot hard...bahot hard" }}
<a href="{{ url('custom_logout') }}">LOGOUT</a>