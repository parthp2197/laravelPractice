<script src="assets/js/jquery-3.2.1.slim.min.js"></script>
  <script src="assets/js/plugins.js"></script>

  <!--Morris Chart-->
  <script src="assets/js/charts/morris/raphael-min.js"></script>
  <script src="assets/js/charts/morris/morris.js"></script>

  <!--Chartist Chart-->
  <script src="assets/js/charts/chartist/chartist.min.js"></script>
  <script src="assets/js/charts/chartist/chartist-plugin-legend.js"></script>

  <!--Sparkline Chart-->
  <script src="assets/js/charts/sparkline/jquery.sparkline.min.js"></script>

  <!--Flot Chart-->
  <script src="assets/js/charts/flot/jquery.flot.js"></script>
  <script src="assets/js/charts/flot/jquery.flot.pie.js"></script>
  <script src="assets/js/charts/flot/jquery.flot.resize.js"></script>
  <script src="assets/js/charts/flot/jquery.flot.spline.js"></script>
  <script src="assets/js/widgets/charts.init.js"></script>

  <!--For Weather-->
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/widgets/weather.js"></script>

  <!--For Calendar-->
  <script src="assets/js/calendar/moment.js"></script>
  <script src="assets/js/calendar/fullcalendar.min.js"></script>

  <script src="assets/js/index/index-01.js"></script>
  <script src="assets/js/main.js"></script>
